"""
 Dummy

 @results     empty array
 @stable      yes
"""


# do search-request
def request(query, params):
    return params


# get response from search-request
def response(resp):
    return []
