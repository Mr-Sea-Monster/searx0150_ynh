# -*- coding: utf-8 -*-

from searx.testing import SearxTestCase


#  TODO
class SearchTestCase(SearxTestCase):

    def test_(self):
        pass
